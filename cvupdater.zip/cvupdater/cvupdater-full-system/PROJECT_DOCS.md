# CVUpdater — Project Documentation

## 1. Requirements

### 1.1 Core differentiator (non-negotiable requirement)
Tailored resumes must retain the user's original formatting exactly — fonts, spacing,
bullet style, layout. This is the reason the product exists. Solved by editing the
source DOCX's OOXML directly (only `<w:t>` text nodes are ever changed) instead of
regenerating a document from a template, which is what RoleReady and most competitors do.

### 1.2 Competitive analysis

**RoleReady.ai** (primary named competitor)
- Kanban application tracker, resume tailoring, fit scoring, interview prep (Questions/
  Research/Letters), Chrome capture, up to 40 tracked jobs on free tier.
- Auth pages are unbranded, generic email/password forms — no product identity carried through.
- No evidence of format-preserving tailoring; standard extract-and-regenerate pattern.

**Teal HQ** (category leader — researched Aug 2026)
- Strengths: generous free tier (unlimited resumes/tracking, Chrome extension scanning 40+
  job boards, ~10 ATS templates, contact manager), fast resume↔tracker↔cover-letter feedback
  loop, treats the job search as a sales pipeline (networking CRM, follow-up reminders).
- Named weaknesses (from published reviews): match score surfaces low-substance/generic
  keywords; **zero interview prep** ("Teal stops at the application stage" — no mock
  interviews, no STAR coaching); AI-generated content needs manual editing to sound authentic;
  premium billed weekly, criticized as easy to lose track of.

### 1.3 Requirements this drove
| Requirement | Source |
|---|---|
| Format-preserving tailoring engine | Core product thesis |
| Fit-score keyword matching must filter stopwords / be substantive | Named weakness in Teal reviews — verified our own stub fallback had this exact bug, fixed |
| Interview Guide is a first-class page, not an afterthought | Teal's most-cited gap |
| Branded, functional auth (not a bare form) | RoleReady's own auth pages are unbranded |
| Networking CRM / contacts (backlog) | Teal's pipeline philosophy — not yet built |
| Chrome capture extension (backlog) | Both competitors have this; we only have a nav stub |

## 2. Design

- **Backend:** Python/FastAPI. Chosen because the tailoring engine needs `lxml` for direct
  OOXML manipulation — keeping the API in the same runtime avoids a second service just to
  talk to it.
- **Data:** SQLAlchemy ORM, Postgres in production / SQLite in dev (swap via `DATABASE_URL`).
- **Auth:** JWT (stateless), bcrypt password hashing (direct, not via passlib — see §4).
- **Frontend:** Static HTML/CSS/JS pages sharing one design system (ink navy / amber accent /
  Space Grotesk + IBM Plex Mono + Inter), generated from a shared Python shell template so
  every page stays visually consistent.
- **Tailoring pipeline:** unzip → parse `word/document.xml` → tag every text run with a
  stable ID + formatting metadata → send only text+metadata to Claude → splice returned text
  back into the *same* XML nodes → re-zip. See `app/docx_engine/extract.py` and
  `app/tailor_service.py`.

## 3. Implementation status

**Done, real (not mocked):**
- User registration/login (JWT), applications CRUD + stage transitions, resume upload with
  real DOCX parsing + format snapshot, full tailoring pipeline producing a real downloadable
  `.docx`, keyword matching with stopword filtering.
- All verified with an end-to-end test (register → upload → create application → tailor →
  download → list → stage update) — see §5.

**Frontend pages built:**

Fully wired to the real backend (verified — real auth, real data, no hardcoded arrays):
- `login.html`, `register.html` — real `/auth/login` and `/auth/register`, JWT stored client-side
- `dashboard.html` — real `GET /applications`, drag-and-drop persists via `PATCH /applications/{id}/stage`, "New application" modal calls `POST /applications`
- `resume-tailor.html` — rewritten from an earlier client-side-only prototype to call the real backend pipeline: uploads via `POST /resumes`, creates/reuses an application, calls `POST /tailor`, downloads the real result via `GET /tailor/{id}/download`. Also reads `?application_id=` from the URL so the dashboard's "Open Resume Tailor" link prefills company/role/JD from a real record.
- `your-resume.html` — upload dropzone wired to `POST /resumes`; format snapshot and parsed-structure tree render real data from `GET /resumes` and `GET /resumes/{id}/structure`. The contact/experience/skills edit form is **not** wired — no backend endpoint exists yet to persist structured profile edits (see backlog).
- `tailored-resumes.html` — real `GET /tailor` (list-all, added this session) with working per-row download
- `general.html` — real `GET/PATCH /auth/me`
- `security.html` — real `POST /auth/change-password`; active-sessions and login-history sections are explicitly labeled as illustrative, since no session-tracking model exists yet

Still static mockups, not wired (need backend features that don't exist yet — see backlog):
- `interview-guide.html` — needs an AI question-generation endpoint
- `interviews.html` — needs a scheduling/calendar data model
- `team.html` — needs a collaboration/invite/permissions model

**Not built yet:** networking CRM/contacts, Chrome capture extension, deployment config, automated tests.

## 4. Notable implementation issues hit and fixed

- `passlib`'s bcrypt backend detection is broken against `bcrypt>=4.0` (a known, unresolved
  upstream incompatibility) — raises `ValueError: password cannot be longer than 72 bytes`
  even for short passwords, and separately fails on `AttributeError: module 'bcrypt' has no
  attribute '__about__'` on `bcrypt==5.x`. Fixed by dropping `passlib` and hashing directly
  with `bcrypt.hashpw`/`bcrypt.checkpw`, pinned to `bcrypt==4.0.1`.
- Initial keyword-matching stub (used when no `ANTHROPIC_API_KEY` is set) returned stopwords
  ("and", "are") as "matched keywords" — the exact shallow-matching flaw reviewers call out
  in a competitor. Fixed with a stopword filter.

## 5. Testing

Backend was run locally and exercised through its real HTTP API with `curl` (not unit-tested
in isolation) — see `backend/README.md` for the exact commands. Re-ran the full regression
suite after this session's frontend-wiring work to make sure nothing broke: health check →
register → update profile → upload real `.docx` → structure correctly extracted → list
resumes → create application → tailor (stub scorer, no `ANTHROPIC_API_KEY` in this sandbox)
→ list all tailored resumes → download → verified the downloaded file is a valid `.docx` →
change password. All passed. Every generated frontend page was also run through a Node.js
syntax check (`new Function(...)` on each inline `<script>` block) after every edit — a
real bug this caught: an over-escaped apostrophe (`\\'`) inside a JS single-quoted string
that would have silently broken the Resume Tailor page's results rendering.

**Not yet covered:** automated test suite (pytest), load testing, the live Claude-backed
tailoring path (only the stub fallback was exercised in this sandbox, since no
`ANTHROPIC_API_KEY` is available here — the code path exists and matches what an earlier
client-side-only prototype already proved works against the real Claude API), and no
browser-based end-to-end test of the frontend against the backend (only the API itself was
tested with curl; the frontend JS wiring was checked for syntax validity, not runtime behavior
in an actual browser).

## 6. Deployment (not done — sandbox has no persistent hosting)

This sandbox resets between sessions, so nothing here is live. To deploy for real:
1. Provision Postgres (Railway, Render, Supabase, RDS — any).
2. Set `DATABASE_URL`, `ANTHROPIC_API_KEY`, `JWT_SECRET` as real environment variables.
3. Deploy `backend/` (Render/Railway/Fly.io all support a FastAPI app directly; a
   `Dockerfile` is the most portable option and isn't included yet — backlog item).
4. Point the frontend's `fetch()` calls at the deployed API's URL instead of `localhost:8000`.
5. Serve the frontend as static files (Vercel/Netlify/Cloudflare Pages) or from FastAPI itself.

## 7. Backlog (prioritized)

1. Wire the last three pages (interview-guide, interviews, team) — each needs a new backend
   feature first (AI question generation, a scheduling model, a collaboration/permissions model).
2. Persist structured-profile edits on Your Resume — needs a new endpoint; currently read-only.
3. Networking CRM / contacts feature (Teal-inspired gap).
4. Chrome capture extension for auto-saving job postings.
5. Automated tests (pytest for backend; the manual curl flow in §5 should become a test suite).
   Also worth adding: a browser-based (e.g. Playwright) test of the frontend against a live
   backend, since current testing only covers the API and a JS syntax check, not runtime
   frontend behavior.
6. Dockerfile + docker-compose for one-command local dev with real Postgres.
7. Rate limiting / usage quotas per plan tier (competitors gate this — needs a pricing model
   decision first, which hasn't been made).
8. Tighten CORS (`allow_origins=["*"]` is fine for local dev, not for a public deployment).
