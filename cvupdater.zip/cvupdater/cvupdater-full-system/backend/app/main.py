from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import engine, Base
from .routers import auth, applications, resumes, tailor
from . import models  # noqa: F401 - ensures models are registered before create_all

Base.metadata.create_all(bind=engine)

app = FastAPI(title="CVUpdater API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten to your real frontend origin(s) in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(applications.router)
app.include_router(resumes.router)
app.include_router(tailor.router)


@app.get("/health")
def health():
    return {"status": "ok"}
