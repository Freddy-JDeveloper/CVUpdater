from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from .. import models, schemas, security
from ..database import get_db

router = APIRouter(prefix="/applications", tags=["applications"])

VALID_STAGES = {"saved", "applied", "interviewing", "decided", "offer", "rejected"}


@router.get("", response_model=List[schemas.ApplicationOut])
def list_applications(db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    return db.query(models.Application).filter(models.Application.owner_id == user.id).order_by(models.Application.created_at.desc()).all()


@router.post("", response_model=schemas.ApplicationOut)
def create_application(payload: schemas.ApplicationCreate, db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    stage = payload.stage if payload.stage in VALID_STAGES else "saved"
    app_ = models.Application(
        owner_id=user.id,
        company=payload.company,
        role=payload.role,
        job_description=payload.job_description,
        stage=stage,
    )
    db.add(app_)
    db.commit()
    db.refresh(app_)
    return app_


@router.patch("/{application_id}/stage", response_model=schemas.ApplicationOut)
def update_stage(application_id: str, payload: schemas.ApplicationStageUpdate, db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    if payload.stage not in VALID_STAGES:
        raise HTTPException(status_code=400, detail=f"stage must be one of {sorted(VALID_STAGES)}")
    app_ = db.query(models.Application).filter(models.Application.id == application_id, models.Application.owner_id == user.id).first()
    if not app_:
        raise HTTPException(status_code=404, detail="Application not found")
    app_.stage = payload.stage
    db.commit()
    db.refresh(app_)
    return app_


@router.delete("/{application_id}")
def delete_application(application_id: str, db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    app_ = db.query(models.Application).filter(models.Application.id == application_id, models.Application.owner_id == user.id).first()
    if not app_:
        raise HTTPException(status_code=404, detail="Application not found")
    db.delete(app_)
    db.commit()
    return {"deleted": True}
