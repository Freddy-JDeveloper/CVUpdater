import os
import uuid

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from typing import List

from .. import models, schemas, security
from ..database import get_db
from ..tailor_service import run_tailoring_pipeline

router = APIRouter(prefix="/tailor", tags=["tailor"])

STORAGE_ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "storage")
TAILORED_DIR = os.path.join(STORAGE_ROOT, "tailored")
WORK_DIR = os.path.join(STORAGE_ROOT, "_work")
os.makedirs(TAILORED_DIR, exist_ok=True)


@router.get("", response_model=List[schemas.TailoredResumeListItem])
def list_all(db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    rows = db.query(models.TailoredResume).join(models.Application).filter(
        models.Application.owner_id == user.id
    ).order_by(models.TailoredResume.created_at.desc()).all()
    return [
        schemas.TailoredResumeListItem(
            id=t.id, application_id=t.application_id,
            company=t.application.company, role=t.application.role,
            stage=t.application.stage, fit_score=t.fit_score, created_at=t.created_at,
        )
        for t in rows
    ]


@router.post("", response_model=schemas.TailoredResumeOut)
def tailor(payload: schemas.TailorRequest, db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    application = db.query(models.Application).filter(
        models.Application.id == payload.application_id, models.Application.owner_id == user.id
    ).first()
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")

    resume = db.query(models.Resume).filter(
        models.Resume.id == payload.resume_id, models.Resume.owner_id == user.id
    ).first()
    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    job = str(uuid.uuid4())
    work_dir = os.path.join(WORK_DIR, job)
    out_path = os.path.join(TAILORED_DIR, f"{job}.docx")

    result = run_tailoring_pipeline(
        source_docx_path=resume.storage_path,
        work_dir=work_dir,
        out_path=out_path,
        job_description=application.job_description or "",
        company=application.company,
        role=application.role,
    )

    application.fit_score = result["fit_score"]
    application.matched_keywords = result["matched"]
    application.gap_keywords = result["gaps"]

    tailored = models.TailoredResume(
        application_id=application.id,
        source_resume_id=resume.id,
        storage_path=out_path,
        edits={e["id"]: {"original": e["original"], "tailored": e["tailored"], "section": e["section"]} for e in result["applied_edits"]},
        fit_score=result["fit_score"],
    )
    db.add(tailored)
    db.commit()
    db.refresh(tailored)

    return tailored


@router.get("/{tailored_id}/download")
def download(tailored_id: str, db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    tailored = db.query(models.TailoredResume).join(models.Application).filter(
        models.TailoredResume.id == tailored_id, models.Application.owner_id == user.id
    ).first()
    if not tailored or not os.path.exists(tailored.storage_path):
        raise HTTPException(status_code=404, detail="Tailored resume not found")
    return FileResponse(
        tailored.storage_path,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        filename="tailored-resume.docx",
    )


@router.get("/by-application/{application_id}", response_model=List[schemas.TailoredResumeOut])
def list_for_application(application_id: str, db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    return db.query(models.TailoredResume).join(models.Application).filter(
        models.Application.id == application_id, models.Application.owner_id == user.id
    ).order_by(models.TailoredResume.created_at.desc()).all()
