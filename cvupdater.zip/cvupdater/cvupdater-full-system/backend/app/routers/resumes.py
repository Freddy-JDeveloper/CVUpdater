import os
import shutil
import uuid

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from typing import List

from .. import models, schemas, security
from ..database import get_db
from ..docx_engine import extract as engine

router = APIRouter(prefix="/resumes", tags=["resumes"])

STORAGE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "storage", "uploads")
os.makedirs(STORAGE_DIR, exist_ok=True)


@router.post("", response_model=schemas.ResumeOut)
def upload_resume(file: UploadFile = File(...), db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    if not file.filename.lower().endswith(".docx"):
        raise HTTPException(status_code=400, detail="Only .docx files are supported (needed to preserve formatting).")

    dest_name = f"{uuid.uuid4()}.docx"
    dest_path = os.path.join(STORAGE_DIR, dest_name)
    with open(dest_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    work_dir = os.path.join(STORAGE_DIR, f"_parse_{uuid.uuid4()}")
    try:
        document_xml_path = engine.unpack_docx(dest_path, work_dir)
        _, records = engine.extract_runs(document_xml_path)
        snapshot = engine.extract_format_snapshot(document_xml_path)
    finally:
        if os.path.exists(work_dir):
            shutil.rmtree(work_dir)

    # mark any existing resumes as non-primary
    db.query(models.Resume).filter(models.Resume.owner_id == user.id).update({"is_primary": False})

    resume = models.Resume(
        owner_id=user.id,
        filename=file.filename,
        storage_path=dest_path,
        structure=records,
        format_snapshot=snapshot,
        is_primary=True,
    )
    db.add(resume)
    db.commit()
    db.refresh(resume)
    return resume


@router.get("", response_model=List[schemas.ResumeOut])
def list_resumes(db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    return db.query(models.Resume).filter(models.Resume.owner_id == user.id).order_by(models.Resume.created_at.desc()).all()


@router.get("/{resume_id}/structure")
def get_structure(resume_id: str, db: Session = Depends(get_db), user: models.User = Depends(security.get_current_user)):
    resume = db.query(models.Resume).filter(models.Resume.id == resume_id, models.Resume.owner_id == user.id).first()
    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")
    return {"structure": resume.structure, "format_snapshot": resume.format_snapshot}
