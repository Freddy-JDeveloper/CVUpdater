import os
import json
import re

from .docx_engine import extract as engine

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")

SYSTEM_PROMPT = """You are a resume tailoring engine. You receive a resume broken into \
text runs (id, text, formatting metadata) and a target job description. Return ONLY \
minified JSON, no markdown fences, no commentary, in exactly this shape:
{"fit_score": <0-100 integer>, "matched": [...up to 6 short keyword strings...], \
"gaps": [...up to 5 short keyword strings...], "edits": {"<run id>": "<new text>", ...}}

Rules:
- Only include a run id in "edits" if you are changing its wording.
- Never invent employers, job titles, dates, or numeric metrics not already present in the given text.
- You may rephrase and add relevant keywords naturally, but keep every claim traceable to the original text.
- Keep each edited run's new text reasonably close in length to the original so layout isn't broken.
- Do not edit section headers, names, dates, or contact info runs.
"""


def _call_claude(records, job_description, company, role):
    if not ANTHROPIC_API_KEY:
        return _stub_response(records, job_description)

    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    payload = [
        {"id": r["id"], "text": r["text"], "bullet": r["bullet"], "section": r["section"], "format": r["format"]}
        for r in records
    ]
    user_msg = (
        f"Target role: {role} at {company}\n\n"
        f"Job description:\n{job_description}\n\n"
        f"Resume runs (JSON):\n{json.dumps(payload)}"
    )
    resp = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1500,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_msg}],
    )
    text = "".join(block.text for block in resp.content if hasattr(block, "text"))
    clean = re.sub(r"```json|```", "", text).strip()
    return json.loads(clean)


STOPWORDS = {
    "the", "and", "for", "are", "you", "with", "will", "have", "this", "that",
    "your", "our", "who", "role", "team", "work", "not", "but", "all", "can",
    "has", "was", "were", "from", "into", "than", "then", "they", "their",
    "about", "also", "any", "such", "each", "other", "when", "what", "how",
    "we", "as", "on", "in", "to", "of", "a", "an", "is", "be", "or", "at",
}


def _stub_response(records, job_description):
    """Deterministic fallback used when ANTHROPIC_API_KEY isn't set, so the
    endpoint is testable/demo-able without live credentials. Does simple
    keyword-overlap scoring — not a substitute for the real model. Filters
    stopwords deliberately: shallow keyword matching that surfaces words
    like 'and'/'are' is a real, named complaint about a competitor's match
    score, and this fallback shouldn't repeat it even as a stub."""
    jd_words = set(re.findall(r"[a-zA-Z][a-zA-Z\-]{2,}", job_description.lower())) - STOPWORDS
    resume_words = set()
    for r in records:
        resume_words |= set(re.findall(r"[a-zA-Z][a-zA-Z\-]{2,}", r["text"].lower()))
    resume_words -= STOPWORDS
    matched = sorted(list(jd_words & resume_words))[:6]
    gaps = sorted(list(jd_words - resume_words))[:5]
    fit = min(95, 40 + len(matched) * 8)
    return {"fit_score": fit, "matched": matched, "gaps": gaps, "edits": {}}


def run_tailoring_pipeline(source_docx_path: str, work_dir: str, out_path: str,
                            job_description: str, company: str, role: str):
    document_xml_path = engine.unpack_docx(source_docx_path, work_dir)
    tree, records = engine.extract_runs(document_xml_path)

    result = _call_claude(records, job_description, company, role)

    applied = engine.apply_edits(tree, result.get("edits", {}))
    # attach section for each applied edit (apply_edits doesn't have it)
    section_by_id = {r["id"]: r["section"] for r in records}
    for a in applied:
        a["section"] = section_by_id.get(a["id"], "Document")

    engine.save_and_repack(tree, document_xml_path, work_dir, out_path)

    return {
        "fit_score": result.get("fit_score", 0),
        "matched": result.get("matched", []),
        "gaps": result.get("gaps", []),
        "applied_edits": applied,
        "output_path": out_path,
        "used_live_model": ANTHROPIC_API_KEY is not None,
    }
