import datetime as dt
from typing import Optional, Any
from pydantic import BaseModel, EmailStr


class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: str
    name: str
    email: str
    job_search_status: str

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class UserUpdate(BaseModel):
    name: Optional[str] = None
    job_search_status: Optional[str] = None


class PasswordChange(BaseModel):
    current_password: str
    new_password: str


class ApplicationCreate(BaseModel):
    company: str
    role: str
    job_description: Optional[str] = None
    stage: Optional[str] = "saved"


class ApplicationStageUpdate(BaseModel):
    stage: str


class ApplicationOut(BaseModel):
    id: str
    company: str
    role: str
    job_description: Optional[str]
    stage: str
    fit_score: Optional[int]
    matched_keywords: Optional[Any]
    gap_keywords: Optional[Any]
    created_at: dt.datetime

    class Config:
        from_attributes = True


class ResumeOut(BaseModel):
    id: str
    filename: str
    format_snapshot: Optional[Any]
    is_primary: bool
    created_at: dt.datetime

    class Config:
        from_attributes = True


class TailorRequest(BaseModel):
    application_id: str
    resume_id: str


class TailoredResumeOut(BaseModel):
    id: str
    application_id: str
    fit_score: Optional[int]
    edits: Optional[Any]
    created_at: dt.datetime

    class Config:
        from_attributes = True


class TailoredResumeListItem(BaseModel):
    id: str
    application_id: str
    company: str
    role: str
    stage: str
    fit_score: Optional[int]
    created_at: dt.datetime

    class Config:
        from_attributes = True
