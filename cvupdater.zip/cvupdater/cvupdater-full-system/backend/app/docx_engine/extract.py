"""
Format-preserving resume tailoring engine — extraction step.

Parses word/document.xml directly (not python-docx's text API) so we keep a
handle on the exact <w:r> nodes. The LLM only ever sees text + formatting
metadata; it never sees or produces markup, so nothing about how a run
looks can change — only what it says.
"""
import zipfile
import shutil
import os
from lxml import etree

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def unpack_docx(src_path: str, work_dir: str) -> str:
    """Unzip a docx into work_dir, return path to word/document.xml"""
    if os.path.exists(work_dir):
        shutil.rmtree(work_dir)
    os.makedirs(work_dir)
    with zipfile.ZipFile(src_path, "r") as z:
        z.extractall(work_dir)
    return os.path.join(work_dir, "word", "document.xml")


def fmt_summary(rPr):
    if rPr is None:
        return {}
    out = {}
    if rPr.find(f"{W}b") is not None:
        out["bold"] = True
    if rPr.find(f"{W}i") is not None:
        out["italic"] = True
    sz = rPr.find(f"{W}sz")
    if sz is not None:
        out["size"] = sz.get(f"{W}val")
    return out


def extract_runs(document_xml_path: str):
    """Returns (tree, records). records is a list of dicts safe to send to
    an LLM. tree is the live lxml tree — callers keep it to apply edits and
    re-serialize without re-parsing."""
    tree = etree.parse(document_xml_path)
    root = tree.getroot()
    body = root.find(f"{W}body")
    records = []
    run_counter = 0
    current_section = "Document"

    for p in body.findall(f"{W}p"):
        pPr = p.find(f"{W}pPr")
        is_bullet = pPr is not None and pPr.find(f"{W}numPr") is not None
        pStyle = pPr.find(f"{W}pStyle") if pPr is not None else None
        style_val = pStyle.get(f"{W}val") if pStyle is not None else None

        para_runs = p.findall(f"{W}r")
        para_text = "".join((r.find(f"{W}t").text or "") for r in para_runs if r.find(f"{W}t") is not None)
        if style_val and "Heading" in style_val and para_text.strip():
            current_section = para_text.strip()

        for r in para_runs:
            t = r.find(f"{W}t")
            if t is None or not (t.text and t.text.strip()):
                continue
            rid = f"r{run_counter}"
            run_counter += 1
            r.set("data-rr-id", rid)  # scratch attribute, stripped before saving
            records.append({
                "id": rid,
                "section": current_section,
                "bullet": is_bullet,
                "format": fmt_summary(r.find(f"{W}rPr")),
                "text": t.text,
            })
    return tree, records


def apply_edits(tree, edits: dict):
    """edits: {run_id: new_text}. Mutates the tree in place. Returns a list
    of {id, section, original, tailored} for the ones actually changed."""
    root = tree.getroot()
    applied = []
    id_to_record = {}
    for r in root.iter(f"{W}r"):
        rid = r.get("data-rr-id")
        if rid is None:
            continue
        if rid in edits and edits[rid] is not None:
            t = r.find(f"{W}t")
            original = t.text
            t.text = edits[rid]
            t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            applied.append({"id": rid, "original": original, "tailored": edits[rid]})
        del r.attrib["data-rr-id"]
    return applied


def save_and_repack(tree, document_xml_path: str, work_dir: str, out_path: str):
    tree.write(document_xml_path, xml_declaration=True, encoding="UTF-8", standalone=True)
    if os.path.exists(out_path):
        os.remove(out_path)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for folder, _, files in os.walk(work_dir):
            for file in files:
                full = os.path.join(folder, file)
                rel = os.path.relpath(full, work_dir)
                zf.write(full, rel)
    return out_path


def extract_format_snapshot(document_xml_path: str):
    """Lightweight summary for the 'Your Resume' format-snapshot panel."""
    tree = etree.parse(document_xml_path)
    root = tree.getroot()
    body = root.find(f"{W}body")
    fonts, sizes, bullets = set(), set(), False
    for r in body.iter(f"{W}r"):
        rPr = r.find(f"{W}rPr")
        if rPr is None:
            continue
        rFonts = rPr.find(f"{W}rFonts")
        if rFonts is not None:
            f = rFonts.get(f"{W}ascii")
            if f:
                fonts.add(f)
        sz = rPr.find(f"{W}sz")
        if sz is not None:
            sizes.add(sz.get(f"{W}val"))
    for p in body.findall(f"{W}p"):
        pPr = p.find(f"{W}pPr")
        if pPr is not None and pPr.find(f"{W}numPr") is not None:
            bullets = True
            break
    return {
        "fonts": sorted(fonts) or ["Default"],
        "sizes_half_points": sorted(sizes),
        "has_bullets": bullets,
    }
