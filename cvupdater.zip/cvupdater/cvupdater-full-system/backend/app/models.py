import uuid
import datetime as dt
from sqlalchemy import Column, String, Integer, Text, ForeignKey, DateTime, JSON, Boolean
from sqlalchemy.orm import relationship
from .database import Base


def uid():
    return str(uuid.uuid4())


class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=uid)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    job_search_status = Column(String, default="open_to_offers")
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    resumes = relationship("Resume", back_populates="owner", cascade="all, delete-orphan")
    applications = relationship("Application", back_populates="owner", cascade="all, delete-orphan")


class Resume(Base):
    """A source resume file the user uploaded. Stores the parsed structure
    (runs + formatting metadata) so the tailoring engine never has to
    re-derive it, and so 'Your Resume' can render the format snapshot."""
    __tablename__ = "resumes"
    id = Column(String, primary_key=True, default=uid)
    owner_id = Column(String, ForeignKey("users.id"), nullable=False)
    filename = Column(String, nullable=False)
    storage_path = Column(String, nullable=False)  # original docx on disk
    structure = Column(JSON, nullable=True)         # extracted runs, see docx_engine.extract
    format_snapshot = Column(JSON, nullable=True)   # font/size/bullet style summary
    is_primary = Column(Boolean, default=True)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    owner = relationship("User", back_populates="resumes")


class Application(Base):
    __tablename__ = "applications"
    id = Column(String, primary_key=True, default=uid)
    owner_id = Column(String, ForeignKey("users.id"), nullable=False)
    company = Column(String, nullable=False)
    role = Column(String, nullable=False)
    job_description = Column(Text, nullable=True)
    stage = Column(String, default="saved")  # saved, applied, interviewing, decided, offer, rejected
    fit_score = Column(Integer, nullable=True)
    matched_keywords = Column(JSON, nullable=True)
    gap_keywords = Column(JSON, nullable=True)
    stage_updated_at = Column(DateTime, default=dt.datetime.utcnow)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    owner = relationship("User", back_populates="applications")
    tailored_resumes = relationship("TailoredResume", back_populates="application", cascade="all, delete-orphan")


class TailoredResume(Base):
    """A generated, format-preserved .docx for one application."""
    __tablename__ = "tailored_resumes"
    id = Column(String, primary_key=True, default=uid)
    application_id = Column(String, ForeignKey("applications.id"), nullable=False)
    source_resume_id = Column(String, ForeignKey("resumes.id"), nullable=False)
    storage_path = Column(String, nullable=False)
    edits = Column(JSON, nullable=True)  # {run_id: {original, tailored}}
    fit_score = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    application = relationship("Application", back_populates="tailored_resumes")
