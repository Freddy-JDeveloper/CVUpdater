# CVUpdater Backend

FastAPI backend: auth, application tracking, resume upload/parsing, and the
format-preserving tailoring engine. See `../PROJECT_DOCS.md` for the full
requirements/design/testing writeup.

## Setup

```bash
python3 -m venv venv
./venv/bin/pip install -r requirements.txt
cp .env.example .env
# edit .env: set ANTHROPIC_API_KEY for real tailoring (optional — falls back
# to a keyword-overlap stub without it), and a real JWT_SECRET before deploying.
```

## Run

```bash
./venv/bin/uvicorn app.main:app --reload --port 8000
```

Visit `http://localhost:8000/docs` for interactive API docs (Swagger UI, auto-generated).

## Manual end-to-end test

```bash
# register
TOKEN=$(curl -s -X POST http://localhost:8000/auth/register -H "Content-Type: application/json" \
  -d '{"name":"Jordan Ellis","email":"jordan@example.com","password":"testpass123"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

# upload a resume (.docx only — needed to preserve formatting)
RESUME_ID=$(curl -s -X POST http://localhost:8000/resumes -H "Authorization: Bearer $TOKEN" \
  -F "file=@/path/to/resume.docx" | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

# create an application
APP_ID=$(curl -s -X POST http://localhost:8000/applications -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"company":"Acme","role":"Backend Engineer","job_description":"..."}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

# tailor
curl -s -X POST http://localhost:8000/tailor -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"application_id\":\"$APP_ID\",\"resume_id\":\"$RESUME_ID\"}"

# download the result (use the id returned above)
curl -s "http://localhost:8000/tailor/<tailored_id>/download" -H "Authorization: Bearer $TOKEN" \
  -o tailored.docx
```

## Project layout

```
app/
  main.py            FastAPI app, CORS, router registration
  database.py         SQLAlchemy engine/session (Postgres via DATABASE_URL, SQLite fallback)
  models.py            User, Resume, Application, TailoredResume
  schemas.py            Pydantic request/response models
  security.py           JWT + bcrypt (direct, not passlib — see PROJECT_DOCS.md §4)
  tailor_service.py     Calls Claude with structured run data, applies edits
  docx_engine/
    extract.py           Core engine: unzip → extract runs → apply edits → re-zip
  routers/
    auth.py, applications.py, resumes.py, tailor.py
```

## Known limitations (see PROJECT_DOCS.md §7 for the full backlog)

- No automated test suite yet — tested manually via the curl flow above.
- CORS is wide open (`allow_origins=["*"]`) — tighten before deploying publicly.
- No rate limiting / usage quotas.
- `ANTHROPIC_API_KEY` unset → falls back to a stopword-filtered keyword-overlap stub instead
  of real tailoring, so the API stays testable without live credentials.
